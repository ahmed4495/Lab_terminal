<div class="wrapper row4">
  <footer id="copyright" class="clear">
    <p class="fl_center">Copyright &copy; 2019 - All Rights Reserved - <a href="#">Ahmed Salman</a></p>
    
  </footer>
</div>