<?php
  // Create database connection
error_reporting(0);
include_once('../global.php');
 include('index.php');


  // Initialize message variable
  $msg = "";
if( $_GET['dellId']!='' ){
	
	$dellid=$_GET['dellId'];
	
	"delete from products where id=".$dellid."";
		mysql_query( "delete from products where id=$dellid") ;
	    $msg = " Records Deleted!"; 
		header('location:items.php');

}


  // If upload button is clicked ...
    if (isset($_POST['upload'])) {
$image=$_FILES["file"]["name"];
 
	  if( $image!=''){
			 $size=getimagesize($_FILES["file"]["tmp_name"]);
			 $size[0];
			 $size[1];
			//if($size[0]=='980' and $size[1]=='425' )
			//{
	  
	  
	  
  	// Get image name
 
  	// Get text
  	 $prName = mysql_real_escape_string($_POST['prName']);
	 $prCategory = mysql_real_escape_string($_POST['prCategory']); 
	 $prPrice = mysql_real_escape_string($_POST['prPrice']);


  	// image file directory
  	$sql = "INSERT INTO products (prImage, prName,prCategory,prPrice) VALUES ('$image', '$prName','$prCategory','$prPrice')";
  	// execute query
	
  	mysql_query($sql);
//move_uploaded_file($_FILES[" myimage "][" tmp_name "], "$folder".$_FILES[" myimage "][" name "]);
if(move_uploaded_file($_FILES["file"]["tmp_name"], "../upload/items/" . $_FILES["file"]["name"]))

  {
  		$msg = "Image uploaded successfully";
		header('location:items.php');

  	}
	
	
	
				
	//}

			
			//else{
				
				//$msg="Please Resize Image";
				
				//}
		
	
			}
			
				else {
		
		 $msg="please select image";
	}
	
	
			
			}
		
 
 
  // If upload button is clicked ...
    if (isset($_POST['edit'])) {
		
		
		$id=$_GET['EditId'];
		
 $image=$_FILES["items"]["name"]; 
 $pic=$_POST['pic'];
 
   	 $prName = mysql_real_escape_string($_POST['prName']);
	    	 $prCategory = mysql_real_escape_string($_POST['prCategory']);
			 
	    	 $prPrice = mysql_real_escape_string($_POST['prPrice']);
	 

 
 // image file directory
  	 $sql = "update products set prName='$prName',prCategory='$prCategory',prPrice='$prPrice' where id='$id'";
  	// execute query
  	mysql_query($sql);
 
 
	if( $image!=''){
		
		
		
			 $size=getimagesize($_FILES["items"]["tmp_name"]);
			 $size[0];
			 $size[1];
			//if($size[0]=='980' and $size[1]=='425' )
			//{  
			
		$sql1 = "update products set prImage='$image' where id='$id'";
		 mysql_query($sql1);
  	
//move_uploaded_file($_FILES[" myimage "][" tmp_name "], "$folder".$_FILES[" myimage "][" name "]);
	if(move_uploaded_file($_FILES["items"]["tmp_name"], "../upload/items/" . $_FILES["items"]["name"]))

  {
  		$msg = "Image edit successfully";
		header('location:items.php?EditId='.$id.'');

  	}	
			//}
			
			
			//else{
				
				//$msg="Please Resize Image";
				
				//}
				
	}

  }
  
  $result = mysql_query( "SELECT * FROM products");

?>
<!DOCTYPE html>
<html>
<body>
<div id="content">
<?
  	if(isset($_GET['method'])&& $_GET['method']=='add')
	{
  ?>
  
  <div class="heading">
    	<h1>ADD New products</h1>
        <div class="extra"></div>

        <div class="clr"></div>
        
    </div>
  <div class="right-add">
    	<a href="?" class="add">Go Back</a>
    </div>
  
      <p class="message"><?=$msg?></p>
    <form method="POST" action="" enctype="multipart/form-data">


    	<table cellpadding="5" cellspacing="0" border="0" class="get-data">
        	<tr height="15">
            	<td>&nbsp;</td>
                <td>&nbsp;</td>
            </tr>
            
        	
            
            
            <tr height="25">
            	<td class="label"><label>Upload items :</label></td>
                <td class="input">
    <input type="file" name="file" id="file" />
                	<span style="color:#990000; font-size:11px;">* Please upload items size of only 970px X 323px (W X H) * </span>
                </td>
            </tr>
            
             <tr>
            	<td class="label"><label class="req">products Name :</label></td>
                <td class="input">
                
              <input type="text"  class="input-small" name="prName" /> 
          
               
              </td>
             </tr>
            
            
               <tr>
            	<td class="label"><label class="req">item Category :</label></td>
                <td class="input"> 
                
           
<select name="prCategory" class="input-small"  required="required">
<option value="">-------------Select Category-------------</option>

<?
			$qry1	=	"select id,title from category ";
			$run1	=	mysql_query($qry1);
			while($row	=	mysql_fetch_array($run1)){
			$bc		=	$row['title'];
			$id		=	$row['id'];		
			 echo "<option value='$id'>$bc</option>";
			}
	?>
	</select>
                 
               
              </td>
             </tr>
            
               <tr>
            	<td class="label"><label class="req">item Price :</label></td>
                <td class="input"> 
                
              <input type="text" name="prPrice"  class="input-small" /> 
          
               
              </td>
             </tr>
            
        </table>
          		<button type="submit" name="upload">ADD</button>
        
        <div class="clr"></div>
        
        </form>


 
<!--  <form method="POST" action="" enctype="multipart/form-data">
  	<input type="hidden" name="size" value="1000000">
  	<div>
    
    <input type="file" name="file" id="file" />
  	</div>
  	<div>
      <textarea 
      	id="text" 
      	cols="40" 
      	rows="4" 
      	name="content" 
      	placeholder="Say something about this image..."></textarea>
  	</div>
  	<div>
  		<button type="submit" name="upload">POST</button>
  	</div>
  </form>-->
  
  <?php } 
  
  elseif(isset($_GET['EditId']) && $_GET['EditId']!=='')
		{
  
  
  
			$query=mysql_query('select * from products where id='.$_GET['EditId']);
			$row=mysql_fetch_array($query);
			 $image=explode('.',$row['prImage']);
		$eciy = $row['prCategory'];

   ?>
   	<!--start heading-->
    <div class="heading">
    	<h1>Edit item Info</h1>
         <div class="extra"></div>

        <div class="clr"></div>
        
    </div>
    <!--end heading-->
    
    <div class="right-add">
    	<a href="?" class="add">Go Back</a>
    </div>
    <p class="message"><?=$msg?></p>
    
    
    <div class="content-block">
    	    <form name="add" method="post" action="" enctype="multipart/form-data" id="form">
    	<table cellpadding="5" cellspacing="0" border="0" class="get-data">
        	<tr height="15">
            	<td>&nbsp;</td>
                <td>&nbsp;</td>
            </tr>
                           <tr>
            	<td class="label"><label class="req">item Category :</label></td>
                <td class="input"> 
                
           
           
           
           <select name="prCategory"  >

<?
 $sql	=	"select id,title from category";
$res2	=	mysql_query($sql);
$c		=	mysql_num_rows($res2);
if($c > 0)
	{
		while($rowa =mysql_fetch_assoc($res2)){
			$tid = $rowa['id'];
		?>
		<option value="<?= $tid;?>"<? if($tid == $eciy){ echo "selected ='selected'";}?>>
		<? echo $rowa['title'];?></option>
		<?
		}
	}
?>
</select>
           
           
           
           
           
              </td>
             </tr>
            
             <tr>
            	<td class="label"><label class="req">items Name :</label></td>
                <td class="input">
                
              <input type="text" value="<?=$row['prName']?>"  class="input-small" name="prName" /> 
          
               
              </td>
             </tr>
            
            
            
               <tr>
            	<td class="label"><label class="req">item Price :</label></td>
                <td class="input"> 
                
              <input type="text" name="prPrice" value="<?php echo $row['prPrice']?>"  class="input-small" /> 
          
               
              </td>
            
             
         		 <tr height="25">
            	<td class="label"><label>Upload item Image :</label></td>
                <td class="input"><input type="file" name="items" class="input-small" value=""/> <img src="../upload/items/<?=$row['prImage']?>" alt="<?=$row['prName']?>" width="100"  />
                
                <input type="hidden" name="pic" value="<?php $row['prImage']   ?>"  />
                
                	<span style="color:#990000; font-size:11px;">* size of only 970px X 323px (W X H) * </span>
                </td>
            </tr>
   
        </table>
        
                  		<button type="submit" class="" name="edit">Edit</button>

       <!-- <input type="hidden" name="old_banner" value="<?=$row['prImage']?>"  />
        <input type="image" name="edit-save" value="submit" src="images/background/finish.jpg" class="submit-form"/>
        <input type="image" name="edit-continue" value="submit" src="images/background/continue.jpg" class="submit-form"/>
        <input type="hidden" name="action" value="edit" id="action"/>-->
        
        <div class="clr"></div>
        
        </form>
        
       
        <div class="clr"></div>
        
    </div>	 
   <?	
		}
  
  else{
  ?>
    <!--end heading-->
    
    <div class="right-add">
    	<a href="?method=add" class="add">Add New</a>
    </div>
  

        <?
			$StrQry = "select * from products where id > 0 ORDER BY id desc";
				             $result=mysql_query($StrQry);

		?>
        <form method="post">
        <table cellspacing="0" cellpadding="0" class="data-list" border="0" id="SortTable">
        	<tr class="heading nodrag nodrop">
                <td class="title">item Image</td>
				<td class="title">item title</td>
                <td class="title">item Category</td>
                <td class="title">item Price</td>


                <td width="30">Edit</td>
            </tr>
            
            <?
		$TrCls = 0;
		while( $RsPg = mysql_fetch_array($result) )
		{//start while
		  $TrCls = (!$TrCls);
		  $recid = $RsPg['id'] ;
		  $image=explode('.',$RsPg['image']);
		   $prCategory = $RsPg['prCategory'] ;

		  
		?>
        <tr>
            <td class="title"><img src="../upload/items/<?=$RsPg['prImage']?>" alt="item" width="300"  /></td>
            <td><?php echo $RsPg['prName']  ?>  </td>
          <?php 
		  $query2 = mysql_fetch_array(mysql_query("select * from category where id = $prCategory "));
							 
			 ?>
            
            <td> <?php echo $query2['title']  ?>
            
             </td>
            <td><?php echo $RsPg['prPrice']  ?></td>
            <td align="center">
            	<a href="items.php?EditId=<?=$recid?>">Edit</a>
                 <a href="items.php?dellId=<?=$recid?>">delete</a>

                
            </td>
        </tr>
        <? 
		$row_count++;
		} //end while
		?>
        </table>
      
		</form>
     
       
    
    </div>
  <?php   
  
  } 
   ?>
</div>
</body>
</html>